package logic.classes

import kotlin.random.Random

class NumbersOfLotto {

    val rnd = Random

    fun getNumOfOtosLotto(): MutableList<Int> {

        var numlist = mutableListOf<Int>()

        for (i in 0..4) {
            numlist.add(rnd.nextInt(1, 91))
        }
        return numlist

    }

    fun getNumOfHatosLotto(): MutableList<Int> {

        var numlist = mutableListOf<Int>()

        for (i in 0..5) {
            numlist.add(rnd.nextInt(1, 45))
        }
        return numlist

    }
}


