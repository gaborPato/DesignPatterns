package logic.classes

import logic.enums.LottoType

object LottoSorsolo {

    fun lottoSzamSorsolo(type: LottoType): String {
        val lottoNumbers = NumbersOfLotto()
        when (type) {

            LottoType.otoslotto -> {
                val sorsjegy = OtosLotto()
                sorsjegy.prepareLotto(lottoNumbers.getNumOfOtosLotto())
                return sorsjegy.getLottoSzelveny()
            }
            LottoType.hatoslotto -> {
                val sorsjegy = HatosLotto()
                sorsjegy.prepareLotto(lottoNumbers.getNumOfHatosLotto())
                return sorsjegy.getLottoSzelveny()

            }

        }
    }
}