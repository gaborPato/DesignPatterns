package logic.interfaces

interface Sorsjegy {

    abstract fun prepareLotto(num: MutableList<Int>);
    fun getLottoSzelveny(): String

}
