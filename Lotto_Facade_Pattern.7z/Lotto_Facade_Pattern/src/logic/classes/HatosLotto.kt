package logic.classes

import logic.interfaces.Sorsjegy

class HatosLotto : Sorsjegy {


    lateinit private var preparedLottoNumbers: String

    override fun prepareLotto(num: MutableList<Int>) {
        preparedLottoNumbers = "hatoslotto szamok: ${num}"
    }

    override fun getLottoSzelveny(): String {
        return preparedLottoNumbers
    }
}