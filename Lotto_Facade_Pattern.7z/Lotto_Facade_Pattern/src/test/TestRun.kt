package test

import logic.classes.LottoSorsolo
import logic.classes.NumbersOfLotto
import logic.classes.OtosLotto
import logic.enums.LottoType
import logic.interfaces.Sorsjegy

fun main() {


    var testLotto = NumbersOfLotto()
    val numOfOtosLotto = testLotto.getNumOfOtosLotto()
    print(numOfOtosLotto)
    println()
    println("--------------------")

    println("")
    var sorsjegy: Sorsjegy = OtosLotto()
    sorsjegy.prepareLotto(NumbersOfLotto().getNumOfOtosLotto())
    println(sorsjegy.getLottoSzelveny())

    println("------facade design pattern------------")
    println(LottoSorsolo.lottoSzamSorsolo(LottoType.otoslotto))
    println(LottoSorsolo.lottoSzamSorsolo(LottoType.hatoslotto))


}