package logic.classes

import logic.interfaces.Sorsjegy


class OtosLotto : Sorsjegy {

    lateinit private var preparedLottoNumbers: String

    override fun prepareLotto(num: MutableList<Int>) {
        preparedLottoNumbers = "ötöslotto szamok: ${num}"
    }

    override fun getLottoSzelveny(): String {
        return preparedLottoNumbers
    }
}