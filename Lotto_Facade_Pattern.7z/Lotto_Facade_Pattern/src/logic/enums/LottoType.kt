package logic.enums

enum class LottoType {

    otoslotto, hatoslotto
}